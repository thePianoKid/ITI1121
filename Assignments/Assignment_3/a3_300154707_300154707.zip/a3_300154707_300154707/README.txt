Name: Gabriel Braden
Student ID: 300154707
Section: B2

Parking lot simulator program. All solutions were written by Gabriel Braden.