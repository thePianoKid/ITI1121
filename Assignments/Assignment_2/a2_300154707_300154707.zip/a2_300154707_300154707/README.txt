ITI 1121 - Lab 2

Author: Gabriel Braden (300154707)
Section: B

This assignment is a command line parking lot simulator. All the solutions are written by the author without any external resources.
Soli Deo Gloria