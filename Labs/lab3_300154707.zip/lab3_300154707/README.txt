Student name: Gabriel Braden
Student number: 300154707
Course code: ITI1121
Lab section: B-2

This archive contains the 3 files of the lab 3, that is, this file (README.txt),
plus the files Utils.java and Rational.java.