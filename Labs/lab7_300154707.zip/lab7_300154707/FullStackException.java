public class FullStackException extends Exception {
    public FullStackException() {}
}